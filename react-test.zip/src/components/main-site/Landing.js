import React from 'react';
import { withRouter } from 'react-router-dom';

import Header from '../main-site/Header';

const Landing = () => {
  
  return (
    <div className="landing">
	  <Header />

      <h1> Test </h1>
    </div>
  );
}

export default withRouter(Landing);
